package com.newsfeed.util;

public class News {

    private int id;
    private String mNewsTitle;
    private String mNewsDetails;
    private String mNewsDate;



}
