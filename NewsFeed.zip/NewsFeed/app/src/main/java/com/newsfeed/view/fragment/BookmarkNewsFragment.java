package com.newsfeed.view.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.newsfeed.R;
import com.newsfeed.adapter.BookMarkAdapter;
import com.newsfeed.adapter.NewsAdapter;
import com.newsfeed.app.NewsFeedApp;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BookmarkNewsFragment extends Fragment {

    @BindView(R.id.rcv_news_bookmark)
    RecyclerView mRecyclerView;

    private RecyclerView.LayoutManager mLayoutManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View rootView = inflater.inflate(R.layout.fragment_bookmark, container, false);
        ButterKnife.bind(this, rootView);

//        mRecyclerView = findViewById(R.id.rcv_news);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setHasFixedSize(true);

        return rootView;

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            BookMarkAdapter newsAdapter = new BookMarkAdapter(getActivity(), NewsFeedApp.getBookmarkVal());
            mRecyclerView.setAdapter(newsAdapter);
        }
    }
}
