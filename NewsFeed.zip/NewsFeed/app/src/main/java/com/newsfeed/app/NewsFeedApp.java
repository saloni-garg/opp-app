package com.newsfeed.app;

import android.app.Application;

public class NewsFeedApp extends Application {

    private static NewsFeedApp mInstance;

    private static int bookmarkVal = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public static NewsFeedApp getInstance(){
        return mInstance;
    }

    public static int getBookmarkVal() {
        return bookmarkVal;
    }

    public static void addBookmark(){
        bookmarkVal = bookmarkVal+1;
    }

    public static void removeBookmark(){
        if(bookmarkVal>0){
            bookmarkVal = bookmarkVal-1;
        }
    }

}
