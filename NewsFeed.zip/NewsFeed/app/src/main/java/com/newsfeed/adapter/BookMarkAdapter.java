package com.newsfeed.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.newsfeed.R;
import com.newsfeed.app.NewsFeedApp;
import com.newsfeed.util.News;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BookMarkAdapter extends RecyclerView.Adapter<BookMarkAdapter.NewsHolder> {

    private Context mContext;
    private String dateStr;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm");
    private int value;

    public BookMarkAdapter(Context context, int value){
        mContext = context;
        this.value = value;
        dateStr = simpleDateFormat.format(new Date());
    }


    @Override
    public void onBindViewHolder(@NonNull NewsHolder newsHolder, final int i) {

        newsHolder.txtNewsDetails.setText(mContext.getString(R.string.news_details));
        newsHolder.txtNewsTitle.setText(mContext.getString(R.string.news_title));
        newsHolder.mTxtNo.setText(mContext.getString(R.string.number, i+1));

        newsHolder.mImgBookMark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NewsFeedApp.removeBookmark();
                Toast.makeText(mContext, "Bookmark removed successfully", Toast.LENGTH_SHORT).show();
                value = NewsFeedApp.getBookmarkVal();
                notifyDataSetChanged();
            }
        });


        newsHolder.mImgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_SUBJECT, "News Title - Lorem ipsum dolor sit amet");
                share.putExtra(Intent.EXTRA_TEXT, "Lorem ipsum dolor sit amet");
                mContext.startActivity(Intent.createChooser(share, "Share News"));
            }
        });


        newsHolder.txtNewsDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                Intent intent = new Intent(Intent.ACTION_EDIT);
                intent.setType("vnd.android.cursor.item/event");
                intent.putExtra("beginTime", cal.getTimeInMillis());
                intent.putExtra("allDay", true);
                intent.putExtra("rrule", "FREQ=YEARLY");
                intent.putExtra("endTime", cal.getTimeInMillis()+60*60*1000);
                intent.putExtra("title", "Lorem ipsum dolor sit amet");
                mContext.startActivity(intent);
            }
        });

    }

    @NonNull
    @Override
    public NewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_news, viewGroup, false);
        return new NewsHolder(view);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
//        return NewsFeedApp.getInstance().getBookmarkVal();
        if(value==0){
            Toast.makeText(mContext, "No bookmarks data", Toast.LENGTH_SHORT).show();
        }
        return value;
    }


    public static class NewsHolder extends RecyclerView.ViewHolder{

        TextView txtNewsTitle;
        TextView txtNewsDetails;
        TextView txtNewsDate;
        ImageView mImgBookMark;
        ImageView mImgShare;
        TextView mTxtNo;

        NewsHolder(View v){
            super(v);
            txtNewsTitle = v.findViewById(R.id.txt_news_title);
            txtNewsDetails = v.findViewById(R.id.txt_news_details);
            txtNewsDate = v.findViewById(R.id.txt_save_date);
            mTxtNo = v.findViewById(R.id.txt_no);
            mImgBookMark = v.findViewById(R.id.img_bookmark);
            mImgShare = v.findViewById(R.id.img_share);
        }

    }

}
